<?php 
    $connect=mysqli_connect("localhost", "root", "", "beta_critiva") or die('not connecteds') ;
    if($connect){
        echo"<script>console.log('connected');</script>";
    }
?>
