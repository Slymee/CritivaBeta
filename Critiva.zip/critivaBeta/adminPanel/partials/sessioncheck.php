<?php
    session_start();
    if(!isset($_SESSION['AdminLoginId'])){
        header("location: admin_login.php");
    }
?>