$(function(){
    $(".xzoom, .xzoom-gallery").xzoom({
        zoomWidth:400,
        tint:"#333",
        xoffset:15,
    });
});