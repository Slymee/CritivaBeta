<!DOCTYPE html>
<html>
    <head>
        <?php
            include('../partials/connection.php');
        ?>
        <?php
            session_start();
            
        ?>

        <?php
            $catName=$_GET['category'];
            $productId=$_GET['pid'];
            $select_product_query="select * from products where p_id=$productId";
            $result=mysqli_query($connect,$select_product_query);
            $row=mysqli_fetch_assoc($result);

            
        ?>
        <?php
            $productRatings=[];
            $select_comment_query="select * from user_ratings where p_id=$productId";
                if($data=mysqli_query($connect,$select_comment_query)){
                    while($rowRating=mysqli_fetch_assoc($data)){?>

                        <?php
                        $productRatings[]=$rowRating;
                        
                    }
                }
         ?>

        <meta charset="utf-8">
        <meta http-eqivalent="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Product | <?php echo $row['p_name'];?></title>
        <link rel="stylesheet" href="css/product.css">
        <!-- FOR-ICON -->
        <link rel="shortcut icon" href="">
        <!-- FOR-SCROLLTOTOP -->
        <script src="javascript/jquery-3.6.0.min.js"></script>
        <!-- for icons -->
        <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>
       
	
    </head>

    <?php
        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $_SESSION['redirectURL'] = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    ?>

    <body>
        <!-- scrollTop -->
      <a id="top"><p id="arrow"></p></a>

      <!-- MAIN -->
        <div class="main-container">
        <!-- nav-bar -->
        <header>
            <h2 onclick="location.href='homePage.php'">CRITIVA</h2> 
       
            <form class="search-bar" action="./searchResults.php" autocomplete="off" method="GET">
                <input type="text" placeholder="search..." name="searchTag">
                    <button type="submit"><img src="images/search-3-24.png"></button>
                </form>
         
              <nav>
                <ul class="nav-link">
                  <li><a href="homePage.php">Home</a></li>
                    <li><a href="categories.php">Categories</a></li>
                    
          
             
                 </ul> 
              </nav>
              <?php 
                  if(isset($_SESSION['UserName'])){?>
                    <div class="cont">
              <a class="cta" href="#">
                  <div class="Btn"><?php echo $_SESSION['UserName'];?><i class="fa fa-caret-down" aria-hidden="true"></i></div>
                  <div class="float-card-info">
                  <i class="gg-close-r"></i>
                      <div class="imgbox"></div>
                      <p><?php echo $_SESSION['UserName'];?></p>
                      <a href="./partials/logout.php" target="_self" class="hire link">Logout</a>
  
  
                  </div>
                </a>
            </div>
                  <?php }else{?>
                      <a class="cta" href="login.php"><button>Login</button></a>
                <?php  }
                ?>
            <!-- <a class="cta" href="login.php"><button>Login</button></a> -->
            
           </header>
           <!-- product-banner -->
           <div class="small-container single-product">
               <div class="row">
                   <div class="col-2">
                    
                       <img src="../uploads/<?php echo $row['p_image'];?>" id="productImg">
                    
                       <div class="small-img-row">
                           
                           </div>
                   </div>
                   <div class="col-2">
                       <P>Category: <strong><?php echo $catName?></strong></P>
                       <h1><?php echo $row['p_name'];?></h1>

                       <?php
                            if(!empty($productRatings)):
                            $sum=0.0;
                            foreach($productRatings as $rating){
                                $sum+=floatval($rating['us_rating']);
                                
                            }
                            $count=count($productRatings);
                            $average=$sum/$count;
                            
                        else:
                            $average=0;
                        endif;
                       
                       ?>
                       


                       
                       <div class="Product-review">
                        <i class="fas fa-star"></i> <?php echo round($average,1);?>/5

                       </div>
                     
                       <a href="./review.php?pid=<?php echo $productId;?>" class="btn">Start Reviewing</a>
                       <a href="#testimonials" class="btn">Search Reviews</a>
                       <h3>Product Details<i class="fa fa-indent"></i></h3>
                       
                       <p>
                            <?php echo $row['p_description'];?>  
                       </p>
                    
               </div>
           </div>
                    </div>





        <!-- Reviews/comment -->
        <section id="testimonials">

            <div class="testimonial-heading">
                <span>reviews</span>
                <h1>Critiva</h1>
            </div>
            <div class="testimonial-box-container">
                
                
                        

                            <?php
                            if(!empty($productRatings)):
                            foreach($productRatings as $rowRating){
                            $user=$rowRating['us_name'];
                            $rating=$rowRating['us_rating'];
                            $review=$rowRating['us_review'];
                            ?>

                            <div class="testimonial-box">
                                <div class="box-top">
                                    <div class="profile">
                                        <div class="profile-img">
                                        <img src="images/1092578.jpg">
                                        </div>
                                    <div class="name-user">
                                    <strong><?php echo $user;?></strong>
                                    <span>@<?php echo $user;?></span>
                                </div>
                            </div>
                            <div class="review">
                            <i class="fas fa-star "></i> <?php echo $rating;?>/5
                            
                            
                            </div>
                            </div>
                            <div class="client-comment"> 
                            <p><?php echo $review;?></p>
                            </div>
                            </div>

                    <?php  }
                    endif;
                    
                ?>


                
                


            </div>

        </section>
        <!-- footer division -->
<footer>
<div class="upper-footer">
  <div class="upper-footer-logo"> <H1>CRITIVA</H1> </div>
  <div class="upper-footer-content">
  <div class="upper-footer-container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>navigation</h4>
  	 			<ul>
  	 				<li><a href="#">home</a></li>
  	 				<li><a href="#">about us</a></li>
             <li><a href="#">our services</a></li>
             <li><a href="#">features</a></li>
  	 				<li><a href="#">contact us</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>categories</h4>
  	 			<ul>
  	 				<li><a href="#">Restraunt</a></li>
  	 				<li><a href="#">automobiles</a></li>
  	 				<li><a href="#">beauty and spas</a></li>
  	 				<li><a href="#">hotels</a></li>
             <li><a href="#">home services</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Help and support</h4>
  	 			<ul>
  	 				<li><a href="#">FAQ</a></li>
  	 				<li><a href="#">supports</a></li>
  	 				<li><a href="#">resources</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>follow us</h4>
           <ul >
  	 				<li id="footer-text"><i class="fa fa-phone" aria-hidden="true"></i>9840172168,01446645</li>
  	 				<li id="footer-text"><i class="fa fa-map-marker" aria-hidden="true"></i>Kathmandu, Nepal</li>
  	 				<li id="footer-text"><i class="fa fa-envelope" aria-hidden="true"></i>critiva@gmail.com</li>
  	 			</ul>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </div>
  <div class="upper-footer-image">
    <img src="../userPanel/images/log.svg" alt="" >
  </div>
</div>
       <div class="rights-container">
       <center>All Rights Reserved<br>@critiva.com</center>
       </div>
     </footer>
    </div>
    <!-- FOR-READMORE -->
    <script src="javascript/readmore.js"></script>
    <!-- <script src="javascript/navigation.js"></script> -->
    
    <!-- FOR-SCROLLTOTOP -->
    <script type="text/javascript">
      
        $(window).scroll(function()
        {
            if ($(window).scrollTop() > 200)
            {
              $("#top").fadeIn();  
            }
            else
            {
                $("#top").fadeOut();
            }
        });
  
        
        $("#top").click(function()
        {
            $('html,body').animate({scrollTop:0},  800);
          }); 
        

          $('.cont .cta').on("click", function(){
            $(".float-card-info").animate({"right":"50px"}, "fast");
        });
        </script>   
    

    </body>
    
</html>