<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/control.css">
    <link rel="stylesheet" href="../style/text-control.css">
    <link rel="stylesheet" href="./style/admin_users.css">
    <script src="https://kit.fontawesome.com/58caef4721.js" crossorigin="anonymous"></script>

    <title>Product</title>
</head>
<body class="f-regular noselect">
    <section class="sidebar">
        <div class="sidebarBrand">
            <h2 class="f-bold"><i class="fa-regular fa-chart-bar"></i>
                <span>CRITIVA</span>
            </h2>
        </div>
        <div class="sidebarMenu">
            <ul>
                <li><a href="./admin_dashboard.php"><i class="fa-solid fa-tv"></i> <span>Dashboard</span></a></li>
                <li><a href="./admin_users.php"><i class="fa-solid fa-users"></i> <span>Users</span></a></li>
                <li><a href="./admin_category.php"><i class="fa-solid fa-book"></i> <span>Category</span></a></li>
                <li><a href="./admin_product.php"><i class="fa-solid fa-box-archive"></i> <span>Product</span></a></li>
                <li><a href="./admin_admins.php"><i class="fa-solid fa-user-secret"></i> <span>Admins</span></a></li>
                <li><a href="./partials/logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Logout</span></a></li>
            </ul>
        </div>
    </section>
    <section class="mainContent p10">
        <header class="mainHeader spacebetween p10">
            <div class="pageName p10">
                <h2><i class="fa fa-bars"></i><span>Users</span></h2>
            </div>
            <div class="adminName p10">
                <h2>Critiva</h2>
                <p>Admin</p>
            </div>
        </header>
        <div class="statsSection p10 w100">
            <div class="statBox w100">

            </div>
        </div>
    </section>
</body>
</html>