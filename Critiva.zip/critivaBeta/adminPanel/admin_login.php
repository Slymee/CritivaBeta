
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/control.css">
    <link rel="stylesheet" href="../style/text-control.css">
    <link rel="stylesheet" href="./style/admin_login.css">
    <script src="https://kit.fontawesome.com/58caef4721.js" crossorigin="anonymous"></script>
    <title>Admin Login</title>
</head>


<?php
    include("./partials/connection.php");
?>


<body class="noselect spacebetween f-regular">
    <div></div>
    <section class="p10">
        <div class="centerText">
            <h1 class="f-bold heading1">Welcome to Admin Panel</h1>
        </div>
        <div class="formPlace mt20">
            <div></div>
            <div class="p10"><h2 class="f-bold heading2">Admin Login</h2></div>
            <div class="p10">
            <form action="./partials/login_valid.php" method="POST">
                <input type="text" name="username" placeholder="Username">
                <input type="password" name="password" placeholder="Password" id="pass">
                <span class="anchor"><i class="fa-regular fa-eye-slash" onclick="toggle(this)"></i></span>
                <button type="submit" class="anchor" name="login">Login</button>
                <div><h3 class="f-thin anchor heading">Forgot Password?</h3></div>
            </form>
            </div>
            <div class="p10">
                <div class="p10 error">
                    <?php
                        if(isset($_GET['error'])){?>
                        <p class="f-light centertext"><?php echo $_GET['error'];?></p>
                        <?php }?>
                </div>
            </div>
        </div>
    </section>
    <script>
        var passfield = document.querySelector("#pass");
        storage = window.localStorage;
        function toggle(eye){
            if(passfield.type == 'text'){
                eye.classList.remove('fa-eye');
                eye.classList.add('fa-eye-slash');

                passfield.type = 'password';
            }else{
                eye.classList.add('fa-eye');
                eye.classList.remove('fa-eye-slash');
                passfield.type = 'text';
            }
        }
    </script>
    <div></div>
</body>
</html>
