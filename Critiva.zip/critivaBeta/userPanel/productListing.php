<!DOCTYPE html>
<html>
    <head>

    <?php
        include('../partials/connection.php');
    ?>
        <?php
          session_start();
        ?>
    <?php
       $catId=$_GET['id'];
       $catName=$_GET['category'];
     ?>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Category | <?php echo $catName?></title>
        <link rel="stylesheet" href="css/productListing.css" type="text/css">
        <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>
        <script src="javascript/jquery-3.6.0.min.js"></script>

    </head>



    <body>
     
    <!-- scrollTop -->
    <a id="top"><p id="arrow"></p></a>   

 <!-- main -->
<div class="mainContainer">

  <header>
    <h2 onclick="location.href='homePage.php'">CRITIVA</h2> 

    <form class="search-bar" action="./searchResults.php" autocomplete="off" method="GET">
                <input type="text" placeholder="search..." name="searchTag">
            <button type="submit"><img src="images/search-3-24.png"></button>
        </form>
 
      <nav>
        <ul class="nav-link">
          <li><a href="homePage.php">Home</a></li>
            <li><a href="categories.php">Categories</a></li>
            
  
     
         </ul> 
      </nav>
      <?php 
                  if(isset($_SESSION['UserName'])){?>
                    <div class="cont">
              <a class="cta" href="#">
                  <div class="Btn"><?php echo $_SESSION['UserName'];?><i class="fa fa-caret-down" aria-hidden="true"></i></div>
                  <div class="float-card-info">
                  <i class="gg-close-r"></i>
                      <div class="imgbox"></div>
                      <p><?php echo $_SESSION['UserName'];?></p>
                      <a href="./partials/logout.php" target="_self" class="hire link">Logout</a>
  
  
                  </div>
                </a>
            </div>
                  <?php }else{?>
                      <a class="cta" href="login.php"><button>Login</button></a>
                <?php  }
                ?>
    
   </header>

<!-- categories -->


  <section class="bigContainer"> 
<div class="boxa">

  <span>Browse </span><h2> <?php echo $catName;?></h2>
</div>
    <div class="container">
    
    <?php 
      $select_query="select * from products where cat_id=$catId";

      if($data=mysqli_query($connect,$select_query)){
        while($row=mysqli_fetch_assoc($data)){ ?>
          <?php
            $productID=$row['p_id'];
            $productName=$row['p_name'];
            $productImage=$row['p_image'];
            $average=0.0;
            $sum=0.0;
            $count=0;
            $selectRating="select us_rating from user_ratings where p_id=$productID";
                if($rateData=mysqli_query($connect,$selectRating)){
                    while($rowRating=mysqli_fetch_assoc($rateData)){

                        if(!empty($rowRating['us_rating'])):
                        


                          $sum+=floatval($rowRating['us_rating']);
                          $count++;

                        

                        
                    endif;
                  
                        
                    }
                    if($count>0):
                      $average=$sum/$count;
                    endif;

                }

          ?>




      
      <div class="card"><a href="./product.php?category=<?php echo $catName?>&pid=<?php echo $productID?>">
        <div class="content">
          <div class="imgBx"><img src="../uploads/<?php echo $productImage?>"></div>
          <div class="contentBx">
          
          <h3><?php echo $productName;?></div>
          <div class="Product-review">
                        <i class="fas fa-star "></i> <?php echo round($average,1);?>/5
                        

                       </div></h3>
          <button value="explore NOW">Review</button>
        </div>
        
           
           

          
      </a>
      </div>
      
      <?php }
      }
    ?>
     
  </div>
</section>
</div>
      <!-- footer division -->
<footer>
<div class="upper-footer">
  <div class="upper-footer-logo"> <H1>CRITIVA</H1> </div>
  <div class="upper-footer-content">
  <div class="upper-footer-container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>navigation</h4>
  	 			<ul>
  	 				<li><a href="#">home</a></li>
  	 				<li><a href="#">about us</a></li>
             <li><a href="#">our services</a></li>
             <li><a href="#">features</a></li>
  	 				<li><a href="#">contact us</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>categories</h4>
  	 			<ul>
  	 				<li><a href="#">Restraunt</a></li>
  	 				<li><a href="#">automobiles</a></li>
  	 				<li><a href="#">beauty and spas</a></li>
  	 				<li><a href="#">hotels</a></li>
             <li><a href="#">home services</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Help and support</h4>
  	 			<ul>
  	 				<li><a href="#">FAQ</a></li>
  	 				<li><a href="#">supports</a></li>
  	 				<li><a href="#">resources</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>follow us</h4>
           <ul >
  	 				<li id="footer-text"><i class="fa fa-phone" aria-hidden="true"></i>9840172168,01446645</li>
  	 				<li id="footer-text"><i class="fa fa-map-marker" aria-hidden="true"></i>Kathmandu, Nepal</li>
  	 				<li id="footer-text"><i class="fa fa-envelope" aria-hidden="true"></i>critiva@gmail.com</li>
  	 			</ul>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </div>
  <div class="upper-footer-image">
    <img src="../userPanel/images/log.svg" alt="" >
  </div>
</div>
       <div class="rights-container">
       <center>All Rights Reserved<br>@critiva.com</center>
       </div>
     </footer>
          
          
          <script src="javascript/navigation.js"></script>
          <script type="text/javascript">
      
            $(window).scroll(function()
            {
                if ($(window).scrollTop() > 200)
                {
                  $("#top").fadeIn();  
                }
                else
                {
                    $("#top").fadeOut();
                }
            });
      
            
            $("#top").click(function()
            {
                $('html,body').animate({scrollTop:0},  800);
              });
              
              $('.cont .cta').on("click", function(){
            $(".float-card-info").animate({"right":"50px"}, "fast");
        });
            
            </script>
    </body>
    
</html>