<!DOCTYPE html>
<html>
    <head>
    <?php
        include('../partials/connection.php');
    ?>




    <?php 
        $productID=$_GET['pid'];
        $select="select * from products where p_id=$productID";
        $rowProduct=mysqli_fetch_assoc(mysqli_query($connect,$select));
        $catID=$rowProduct['cat_id'];
        $select_category="select cat_name from categories where cat_id=$catID";
        $rowCategory=mysqli_fetch_assoc(mysqli_query($connect,$select_category));
  
      ?>

        <meta charset="utf-8">
        <meta http-eqivalent="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Review | <?php echo $rowProduct['p_name']?></title>
        <link rel="stylesheet" href="css/review.css">
        <!-- FOR-ICON -->
        <link rel="shortcut icon" href="images/12.png">
        <!-- FOR-SCROLLTOTOP -->
        <script src="javascript/jquery-3.6.0.min.js"></script>
        <!-- rating system -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

        <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>
        
    </head>

    <?php
      session_start();
      if(!isset($_SESSION['UserName'])){
          header("location: ./login.php");
      }
    ?>
    <body>


       

      <!-- MAIN -->
        <div class="main-container">
        <!-- nav-bar -->
        <header>
        <h2 onclick="location.href='homePage.php'">CRITIVA</h2> 
       
            <form class="search-bar" action="./searchResults.php" autocomplete="off" method="GET">
                <input type="text" placeholder="search..." name="searchTag">
                    <button type="submit"><img src="images/search-3-24.png"></button>
                </form>
         
              <nav>
                <ul class="nav-link">
                  <li><a href="homePage.php">Home</a></li>
                    <li><a href="categories.php">Categories</a></li>
                    
          
             
                 </ul> 
              </nav>
              <?php 
                  if(isset($_SESSION['UserName'])){?>
                    <div class="cont">
              <a class="cta" href="#">
                  <div class="Btn"><?php echo $_SESSION['UserName'];?><i class="fa fa-caret-down" aria-hidden="true"></i></div>
                  <div class="float-card-info">
                  <i class="gg-close-r"></i>
                      <div class="imgbox"></div>
                      <p><?php echo $_SESSION['UserName'];?></p>
                      <a href="./partials/logout.php" target="_self" class="hire link">Logout</a>
  
  
                  </div>
                </a>
            </div>
                  <?php }else{?>
                      <a class="cta" href="login.php"><button>Login</button></a>
                <?php  }
                ?>
            <!-- <a class="cta" href="login.php"><button>Login</button></a> -->
            
           </header>
           <!-- product-banner -->
           <div class="small-container single-product">
               <div class="row">
                   <div class="col-2">
                       <img src="../uploads/<?php echo $rowProduct['p_image'];?>" width="100%" height="100%" id="productImg">
                       <div class="small-img-row">
                           
                       </div>
                   </div>
                   <div class="col-2">
                       <P>Category: <?php echo $rowCategory['cat_name'];?></P>
                       <h1><?php echo $rowProduct['p_name'];?></h1>
                       
                       
                       <h4>Write a Review<i class="fa fa-indent"></i></h4>
                       <div class="comment-box">
                    <form action="" method="POST" autocomplete="off">
                             <div class="rateyo" id= "rating"
                             data-rateyo-rating="0"
                             data-rateyo-num-stars="5"
                             data-rateyo-score="3">
                       </div>
                       <span class='result'>rating</span>
                             <input type="hidden" name="rating">

                                <textarea name="comment" placeholder="Type Your Review...." name="comment"></textarea><br>
                                   <button type="submit" name="comment_submit">Submit</button>
                        
                        <?php
                            if(isset($_POST['comment_submit'])){
                                $prevURL=$_SESSION['redirectURL'];
                                $review=$_POST['comment'];
                                $rating=floatval($_POST['rating']);
                                $username=$_SESSION['UserName'];
                                $insert="insert into user_ratings (us_name, p_id, us_rating, us_review)
                                values('$username', $productID, $rating, '$review')";
                                if(mysqli_query($connect, $insert)){
                                    header("location:$prevURL");
                                }else{
                                    echo "failed";
                                }

                            }
                        ?>

                </form>
                
               
            </div>
                        
                        
                   </div>
               </div>
           </div>
<!-- footer division -->
<footer>
<div class="upper-footer">
  <div class="upper-footer-logo"> <H1>CRITIVA</H1> </div>
  <div class="upper-footer-content">
  <div class="upper-footer-container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>navigation</h4>
  	 			<ul>
  	 				<li><a href="#">home</a></li>
  	 				<li><a href="#">about us</a></li>
             <li><a href="#">our services</a></li>
             <li><a href="#">features</a></li>
  	 				<li><a href="#">contact us</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>categories</h4>
  	 			<ul>
  	 				<li><a href="#">Restraunt</a></li>
  	 				<li><a href="#">automobiles</a></li>
  	 				<li><a href="#">beauty and spas</a></li>
  	 				<li><a href="#">hotels</a></li>
             <li><a href="#">home services</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Help and support</h4>
  	 			<ul>
  	 				<li><a href="#">FAQ</a></li>
  	 				<li><a href="#">supports</a></li>
  	 				<li><a href="#">resources</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>follow us</h4>
           <ul >
  	 				<li id="footer-text"><i class="fa fa-phone" aria-hidden="true"></i>9840172168,01446645</li>
  	 				<li id="footer-text"><i class="fa fa-map-marker" aria-hidden="true"></i>Kathmandu, Nepal</li>
  	 				<li id="footer-text"><i class="fa fa-envelope" aria-hidden="true"></i>critiva@gmail.com</li>
  	 			</ul>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </div>
  <div class="upper-footer-image">
    <img src="../userPanel/images/log.svg" alt="" >
  </div>
</div>
       <div class="rights-container">
       <center>All Rights Reserved<br>@critiva.com</center>
       </div>
     </footer>
    </div>
    <script src="javascript/navigation.js"></script>
    <!-- FOR-PRODUCT -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
 
<script>
    $(function () {
        $(".rateyo").rateYo().on("rateyo.change", function (e, data) {
            var rating = data.rating;
            $(this).parent().find('.score').text('score :'+ $(this).attr('data-rateyo-score'));
            $(this).parent().find('.result').text('rating :'+ rating);
            $(this).parent().find('input[name=rating]').val(rating); //add rating value to input field
        });
    });

    $('.cont .cta').on("click", function(){
            $(".float-card-info").animate({"right":"50px"}, "fast");
        });
    </script>
    </body>
</html>

