<?php
    include('connection.php');
?>

<?php
    $id=$_GET['id'];
    $query="delete from products where p_id=$id";
    mysqli_query($connect,$query);
    header("location: ../admin_product.php");
?>