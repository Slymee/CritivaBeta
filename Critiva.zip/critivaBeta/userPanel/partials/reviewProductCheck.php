<?php
    session_start();


    if(isset($_SESSION['UserName'])){
        // header("location: ../review.php");
        header("location: ../login.php");
    }else{
        // header("location: ../login.php");
        header("location: ../review.php");

    }
?>