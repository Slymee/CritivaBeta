<?php
    // include('../../partials/connection.php');
?>
<?php
    $username=NULL;
    $email=NULL;
    $password=NULL;
    $retypePassword=NULL;
    if(isset($_POST['signup'])){
        $username=$_POST['signup_name'];
        $email=$_POST['signup_email'];
        $password=$_POST['signup_pass'];
        $retypePassword=$_POST['signup_repass'];

        $select_username="select * from user_login where us_name='$username'";
        $usernameData=mysqli_query($connect,$select_query);
        $select_email="select * from user_login where email='$email'";
        $emailData=mysqli_query($connect, $select_email);

        if(mysqli_num_rows($usernameData)>0){
            echo "Username Taken!";
        }else{
            if(mysqli_num_rows($emailData)>0){
                echo "Email address exists!";
            }else{
                if($password!=$retypePassword){
                    echo "Password Mismatch!";
                }else{
                    $signup_query="insert into user_login (us_name, email, us_password)
                    values('$username', '$email', '$retypePassword')";
                    mysqli_query($connect, $signup_query);
                    echo "Ready to Login";
                }
            }

        }

    }
?>