<?php
    include('connection.php');
?>

<?php
    $id=$_GET['id'];
    $query="delete from categories where cat_id=$id";
    mysqli_query($connect,$query);
    header("location: ../admin_category.php");
?>