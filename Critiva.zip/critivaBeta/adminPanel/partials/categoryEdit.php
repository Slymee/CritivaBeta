<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../style/control.css">
    <link rel="stylesheet" href="../../style/text-control.css">
    <link rel="stylesheet" href="../style/categoryAdd.css">
    <script src="https://kit.fontawesome.com/58caef4721.js" crossorigin="anonymous"></script>

    <title>Admin | Category Edit</title>
</head>

<?php
    include('connection.php');
?>
<?php
    include('sessioncheck.php');
?>

<?php
    $id1=$_GET['id'];
    $select1="select cat_name from categories where cat_id=$id1";
    $data1=mysqli_query($connect,$select1);
    $row1=mysqli_fetch_assoc($data1);
?>

<body class="f-regular noselect">
    <section class="sidebar">
        <div class="sidebarBrand">
            <h2 class="f-bold"><i class="fa-regular fa-chart-bar"></i>
                <span>CRITIVA</span>
            </h2>
        </div>
        <div class="sidebarMenu">
            <ul>
                <li><a href="../admin_dashboard.php"><i class="fa-solid fa-tv"></i> <span>Dashboard</span></a></li>
                <li><a href="../admin_users.php"><i class="fa-solid fa-users"></i> <span>Users</span></a></li>
                <li><a href="../admin_category.php"><i class="fa-solid fa-book"></i> <span>Category</span></a></li>
                <li><a href="../admin_product.php"><i class="fa-solid fa-box-archive"></i> <span>Product</span></a></li>
                <li><a href="../admin_admins.php"><i class="fa-solid fa-user-secret"></i> <span>Admins</span></a></li>
                <li><a href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Logout</span></a></li>
            </ul>
        </div>
    </section>
    <section class="mainContent p10">
        <header class="mainHeader spacebetween p10">
            <div class="pageName p10">
                <h2><i class="fa fa-bars"></i><span>Edit Category</span></h2>
            </div>
            <div class="adminName p10">
                <h2><?php echo $_SESSION['AdminLoginId']?></h2>
                <p>Admin</p>
            </div>
        </header>
        <div class="spacebetween p10 w100 addSection">
            <div></div>
            <div class="formPlace p10 w50">
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="new_name" placeholder=<?php echo $row1['cat_name']; ?>>
                    <div class="spacebetween p10 imgSelect">
                        <label for="img" class="p10 f-bold">Icon: </label>
                        <input type="file" name="new_image" accept="image/png, image/jpeg">
                    </div>
                    <button class="anchor" name="submit">Submit</button>
                </form>
            </div>
            <div></div>
        </div>
    </section>
</body>
</html>


<?php
    if(isset($_POST['submit'])){
        $id=$_GET['id'];
        $name=NULL;
        $image=NULL;
        $name=$_POST['new_name'];
        $image=$_FILES['new_image']['name'];

        if($name!=NULL && $image!=NULL){
            $image_ext=pathinfo($image, PATHINFO_EXTENSION);
            $filename=time().'.'.$image_ext;
            $query="update categories set 
            cat_name='$name', cat_image='$filename' where cat_id=$id";
            mysqli_query($connect, $query);
            move_uploaded_file($_FILES['new_image']['tmp_name'], '../../uploads/'.$filename);
            header("location: ../admin_category.php");
        }

        if($name!=NULL && $image==NULL){
            $query="update categories set
            cat_name='$name' where cat_id=$id";
            mysqli_query($connect,$query);
            header("location: ../admin_category.php");
        }

        if($name==NULL && $image!=NULL){
            $image_ext=pathinfo($image, PATHINFO_EXTENSION);
            $filename=time().'.'.$image_ext;
            $query="update categories set 
            cat_image='$filename' where cat_id=$id";
            mysqli_query($connect,$query);
            move_uploaded_file($_FILES['new_image']['tmp_name'], '../../uploads/'.$filename);
            header("location: ../admin_category.php");
        }

        if($name==NULL && $image==NULL){
            header("location: ../admin_category.php");        
        }
    }

    if(isset($_POST['back'])){
        header("location: ../admin_category.php");
    }
?>