<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Critiva</title>
        <link rel="stylesheet" href="css/index.css" type="text/css">
        <script src="https://kit.fontawesome.com/64d58efce2.js"crossorigin="anonymous"></script>
    </head>
    <body>
        <section>
        <div class="main-container">
           
            <header>
           <h2>CRITIVA</h2>
           <nav>
           <ul class="nav-link">
               <li><a href="homePage.php">Home</a></li>
               <li><a href="categories.php">Categories</a></li>
               <li><a href="aboutUs.php">About Us</a></li>
               
           </ul> 
        </nav>
        <section>
           <a class="cta" href="login.php"><button>Login</button></a>
           
           
        </section>
       </header>
 
        <div class="bg-image">
            <center><div class="banner"><h1 onclick="location.href='homePage.php'">Critiva</h1></div>
            <form class="search-bar" action="./searchResults.php" autocomplete="off" method="GET">
                <input type="text" placeholder="search..." name="searchTag">
    
                <button type="submit"><img src="images/search-3-24.png"></button>
            </form>
            <div class="lower-banner"><p>A platform for reviewing and rating<br>any product or services </p></div>
            <div class="home-page-banner"><a href="homePage.php"><h2>Go to Home Page</h2></a></div></center>
            </div>
         
<!-- footer division -->
<footer>
<div class="upper-footer">
  <div class="upper-footer-logo"> <H1>CRITIVA</H1> </div>
  <div class="upper-footer-content">
  <div class="upper-footer-container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>navigation</h4>
  	 			<ul>
  	 				<li><a href="#">home</a></li>
  	 				<li><a href="#">about us</a></li>
             <li><a href="#">our services</a></li>
             <li><a href="#">features</a></li>
  	 				<li><a href="#">contact us</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>categories</h4>
  	 			<ul>
  	 				<li><a href="#">Restraunt</a></li>
  	 				<li><a href="#">automobiles</a></li>
  	 				<li><a href="#">beauty and spas</a></li>
  	 				<li><a href="#">hotels</a></li>
             <li><a href="#">home services</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Help and support</h4>
  	 			<ul>
  	 				<li><a href="#">FAQ</a></li>
  	 				<li><a href="#">supports</a></li>
  	 				<li><a href="#">resources</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>follow us</h4>
           <ul >
  	 				<li id="footer-text"><i class="fa fa-phone" aria-hidden="true"></i>9840172168,01446645</li>
  	 				<li id="footer-text"><i class="fa fa-map-marker" aria-hidden="true"></i>Kathmandu, Nepal</li>
  	 				<li id="footer-text"><i class="fa fa-envelope" aria-hidden="true"></i>critiva@gmail.com</li>
  	 			</ul>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </div>
  <div class="upper-footer-image">
    <img src="../userPanel/images/log.svg" alt="" >
  </div>
</div>
       <div class="rights-container">
       <center>All Rights Reserved<br>@critiva.com</center>
       </div>
     </footer>
        
            </div>
        </section>

    </body>
</html>