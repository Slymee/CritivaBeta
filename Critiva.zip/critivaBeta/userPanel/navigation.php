<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Critiva</title>
        <link rel="stylesheet" href="css/navigation.css" type="text/css">
        <script src="javascript/jquery-3.6.0.min.js"></script>
        <script src="https://kit.fontawesome.com/64d58efce2.js"
        crossorigin="anonymous"></script>
        <link type="text/javascript" src="javascript/jquerycdn.js">
    </head>
    <body>
<!-- main -->
        <div class="main-container">
            
             <header>
              <h2 onclick="location.href='homePage.php'">CRITIVA</h2> 
         
                  <form action="#" method="POST" class="search-bar">
                      <input type="text" placeholder="search anything" name="q">
                      <button type="submit"><img src="images/search-3-24.png"></button>
                  </form>
           
                <nav>
                  <ul class="nav-link">
                    <li><a href="homePage.php">Home</a></li>
                      <li><a href="categories.php">Categories</a></li>

                   </ul> 
                </nav>
                <div class="cont">
              <a class="cta" href="#">
                  <div class="Btn">Dhundup<i class="fa fa-caret-down" aria-hidden="true"></i></div>
                  <div class="float-card-info">
                  <i class="gg-close-r"></i>
                      <div class="imgbox"></div>
                      <p>ayush</p>
                      <a href="https://pph.me/webcifar" target="_self" class="hire link">Logout</a>
  
  
                  </div>
                </a>
            </div>
             </header>
</div>
<script type="text/javascript" src="javascript/navigation.js">

</script>
             </body>
</html>