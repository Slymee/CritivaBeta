const name=document.getElementById('name')
const password=document.getElementById('password')
const form=document.getElementById('form')

form.addEventListener('submit',(e)=>{
    let message=[]
    if(name.vaue === ''|| name.value==null){
        message.push('Name is required')
    }
    if(password.value.length<=6){
        message.push('password must be longer than 6 characters')
    }
    if (password.value,length>=20){
        message.push('password must be shorter than 20 characters')
    }
    if(message.length>0){
        e.preventDefault()
        errorElement.innerText=message.join(', ')

    }
   
});
