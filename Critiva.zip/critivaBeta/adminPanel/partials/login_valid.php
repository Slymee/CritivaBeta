<?php 
    include("connection.php");
?>



<?php  
    if(isset($_POST['login'])){
        $username=$_POST['username'];
        $password=$_POST['password'];


        $result=mysqli_query($connect,"select * from admin_login where 
        ad_username='$username' and ad_password='$password'")
        or die("Failed to query ");

        if(mysqli_num_rows($result) > 0){
            session_start();
            $_SESSION['AdminLoginId']=$username;
            header("location: ../admin_dashboard.php");
        }else{
            header("location: ../admin_login.php?error=Invalid Username or Password!");
        }
    }
?>