<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/control.css">
    <link rel="stylesheet" href="../style/text-control.css">
    <link rel="stylesheet" href="./style/admin_product.css">
    <script src="https://kit.fontawesome.com/58caef4721.js" crossorigin="anonymous"></script>

    <title>Admin | Product</title>
</head>

<?php
    include('./partials/connection.php');
?>

<?php
    include('./partials/sessioncheck.php');
?>

<body class="f-regular noselect">
    <section class="sidebar">
        <div class="sidebarBrand">
            <h2 class="f-bold"><i class="fa-regular fa-chart-bar"></i>
                <span>CRITIVA</span>
            </h2>
        </div>
        <div class="sidebarMenu">
            <ul>
            <li><a href="./admin_dashboard.php"><i class="fa-solid fa-tv"></i> <span>Dashboard</span></a></li>
                <li><a href="./admin_users.php"><i class="fa-solid fa-users"></i> <span>Users</span></a></li>
                <li><a href="./admin_category.php"><i class="fa-solid fa-book"></i> <span>Category</span></a></li>
                <li><a href="./admin_product.php"><i class="fa-solid fa-box-archive"></i> <span>Product</span></a></li>
                <li><a href="./admin_admins.php"><i class="fa-solid fa-user-secret"></i> <span>Admins</span></a></li>
                <li><a href="./partials/logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Logout</span></a></li>
            </ul>
        </div>
    </section>
    <section class="mainContent p10">
        <header class="mainHeader spacebetween p10">
            <div class="pageName p10">
                <h2><i class="fa fa-bars"></i><span>Product</span></h2>
            </div>
            <div class="adminName p10">
                <h2><?php echo $_SESSION['AdminLoginId']?></h2>
                <p>Admin</p>
            </div>
        </header>
        <div class="p10 w100 spacebetween">
            <div class="addProduct w100 p10" onclick="location.href='./partials/productAdd.php'">
                <h2>Add Product</h2>
            </div>
        </div>
        <div class="p10">
            <div class="p10"><h2>Product Table</h2></div>
            <div class="p10 tablePlace">
                <table class="tableContent">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Tag</th>
                            <th>Description</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $select_query="select * from products";
                            if($data=mysqli_query($connect,$select_query)){
                                while($row=mysqli_fetch_assoc($data)){?>
                                <?php
                                    $id=$row['p_id'];
                                    $catId=$row['cat_id'];
                                    $name=$row['p_name'];
                                    $image=$row['p_image'];
                                    $tag=$row['p_tag'];
                                    $description=$row['p_description'];
                                ?>
                                <tr>
                                    <td><?php echo $id?></td>
                                    <td><?php echo $catId?></td>
                                    <td><?php echo $name?></td>
                                    <td><?php echo $image?></td>
                                    <td><?php echo $tag?></td>
                                    <td><?php echo $description?></td>
                                    <td><button onclick="location.href='./partials/productEdit.php?id=<?php echo $id;?>'">Edit</button></td>
                                    <td><button onclick="location.href='./partials/productDelete.php?id=<?php echo $id;?>'">Delete</button></td>
                                </tr>
                                <?php }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>
</html>